A Pen created at CodePen.io. You can find this one at http://codepen.io/elemental-shift/pen/kHjcu.

 This is a concept project to play with different methods of vertical scrolling with sectioned content. It doesn't play well with mobile devices though.